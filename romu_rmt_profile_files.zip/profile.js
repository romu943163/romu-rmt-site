document.getElementById('profileForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const user = firebase.auth().currentUser;
  if (!user) {
    alert("ログインが必要です");
    return;
  }

  const displayName = document.getElementById('displayName').value;
  const bio = document.getElementById('bio').value;
  const file = document.getElementById('profileImage').files[0];

  let imageUrl = "";

  if (file) {
    const storageRef = firebase.storage().ref('profileImages/' + user.uid);
    await storageRef.put(file);
    imageUrl = await storageRef.getDownloadURL();
  }

  await firebase.firestore().collection('users').doc(user.uid).set({
    displayName,
    bio,
    imageUrl
  }, { merge: true });

  alert("プロフィールを更新しました");
});